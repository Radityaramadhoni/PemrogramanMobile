package com.example.accountfragment;

public class CallbackFragment {

    public void changeFragment() {
    }
}
